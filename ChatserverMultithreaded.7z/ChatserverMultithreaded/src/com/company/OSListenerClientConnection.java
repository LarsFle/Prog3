package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by Elpunkto on 1/22/2017.
 */
public class OSListenerClientConnection implements Runnable {

    private BufferedReader br;
    private Server server;


    public OSListenerClientConnection(InputStream is, Server server){
        this.br = new BufferedReader(new InputStreamReader(is));
        this.server = server;
    }

    @Override
    public void run() {
        try{
        while (true){


            String msg;
            if ((msg = br.readLine())!=null){
            server.setMsg(msg);

            }
            Thread.sleep(100);
        }}
        catch (IOException ex){
            ex.printStackTrace();
            try{
            br.close();}
            catch (IOException exep)
            {
                exep.printStackTrace();
            }

        }
        catch (InterruptedException ex){
            ex.printStackTrace();
        }

    }
}
