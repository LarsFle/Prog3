package com.company;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import static java.lang.System.in;

/**
 * Created by Elpunkto on 1/21/2017.
 */
public class Server {

private ServerSocket ServerPort;
public int PortNumber;
public List<ClientConnection> Clients;

    public synchronized void setMsg(String msg) {
        this.msg = msg;
        System.out.println(msg);
        for (ClientConnection c: Clients
             ) {
            c.SendMessage(this.msg);
        }
        this.msg = null;
    }

    private String msg;

public Server(int port){
    this.Clients = new ArrayList<ClientConnection>();
    this.PortNumber = port;
}

public void Run(){
    try{
        ServerPort = new ServerSocket(PortNumber);

        while (true){
            Socket clientSocket = ServerPort.accept();
            ClientConnection c = new ClientConnection(clientSocket,this);
            Clients.add(c);



        }


    }
    catch (IOException ex){
        ex.printStackTrace();
    }
}

}
