package com.company;

import java.io.*;
import java.net.Socket;

/**
 * Created by Elpunkto on 1/21/2017.
 */
public class ClientConnection  {

    private Socket Connection;
    private BufferedReader br;
    private PrintWriter pw;
    private Server server;

    public void setOutMsg(String msg) {
        this.OutMsg = msg;
    }

    public String InMsg;
    private   String OutMsg;

    public ClientConnection(Socket socket, Server server){
        try{
            this.server = server;
        this.Connection = socket;
        br = new BufferedReader(new InputStreamReader(this.Connection.getInputStream()));
        pw = new PrintWriter(this.Connection.getOutputStream());
        Thread t = new Thread(new OSListenerClientConnection(this.Connection.getInputStream(),this.server));
        t.start();
        }
        catch (IOException ex){
            ex.printStackTrace();
        }

    }

    public void SendMessage(String msg){
        pw.println(msg);
        pw.flush();
    }


}
