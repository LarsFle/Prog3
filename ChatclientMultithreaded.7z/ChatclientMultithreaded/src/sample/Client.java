package sample;

import java.io.*;
import java.net.*;

/**
 * Created by Elpunkto on 1/9/2017.
 */
public  class Client{

    private Socket ChatSocket;
    private PrintWriter pw;
    private  BufferedReader br;
    private int PortNumber;
    private String IP;
    private  OSListenerClient listener;

    private Controller view;

    public String chatText;

    public Client( Controller view){

        this.view = view;

    }

    public void OpenSocket(String IP, int portNumber) {
        try{
            if(listener != null){
                listener.isAlive = false;
            }
        ChatSocket = new Socket(IP, portNumber);
        pw = new PrintWriter(ChatSocket.getOutputStream());
        br = new BufferedReader(new InputStreamReader(ChatSocket.getInputStream()));
        listener = new OSListenerClient(ChatSocket.getInputStream(),this);
        Thread t = new Thread(listener);
        t.start();
            chatText = "Connected\n";}
        catch (IOException ex){
            ex.printStackTrace();
            chatText = "Unable to connect..\n";
        }


    }

    public void UpdateView(){
        view.Update();

    }

    public  void CloseSocket() throws IOException{
        pw.close();
    }

    public void SendMessage(String message){
        pw.println(message);
        pw.flush();
    }



}
