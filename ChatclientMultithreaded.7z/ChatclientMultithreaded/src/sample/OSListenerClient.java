package sample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by Elpunkto on 1/22/2017.
 */
public class OSListenerClient implements Runnable {

    private BufferedReader br;
    private Client client;
    public boolean isAlive;


    public OSListenerClient(InputStream is, Client client){
        this.br = new BufferedReader(new InputStreamReader(is));
        this.client = client;
        this.isAlive = true;
    }

    @Override
    public void run() {
        try{
        while (isAlive){
            String msg;
            if ((msg = br.readLine())!=null){
            client.chatText += msg+"\n";
            client.UpdateView();

            }
            Thread.sleep(100);
        }}
        catch (IOException ex){
            ex.printStackTrace();
        }
        catch (InterruptedException ex){
            ex.printStackTrace();
        }

    }
}
