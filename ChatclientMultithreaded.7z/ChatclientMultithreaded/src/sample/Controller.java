package sample;

import javafx.scene.control.*;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.awt.*;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;


public class Controller {

   public TextArea textArea;
   public javafx.scene.control.TextField textField;
   private Client c;
   public TextField tfName;
   public TextField tfIP;
   public TextField tfPort;

   public  Controller() throws IOException{
       c = new Client(this);




   }

   public void Update(){
       textArea.setText(c.chatText);
       textArea.setScrollTop(Double.MAX_VALUE);
   }

   public void onKeyPressed(KeyEvent e){
        if(e.getCode().equals(KeyCode.ENTER)){
            c.SendMessage(tfName.getText()+": "+textField.getText());
            textField.setText("");
        }
   }

   public  void onConnect(){

       c.OpenSocket(tfIP.getText(),Integer.parseInt(tfPort.getText()));

       textArea.setText(c.chatText);
   }

   public  void onRefresh(MouseEvent e) throws  IOException{
        c.SendMessage(tfName.getText()+": "+textField.getText());
        textField.setText("");


   }



}
